In order to deal with the problem, we design a class, named CowRecord, to store all the records' message.

In the class, we use a min heap to store the weight, and a class attribute(least) to record the least weight.
Because we create the min heap, the runtime complexity is O(logN). Then as to different cows, the total runtime
is O(c * log(N)). Beside, we should add the runtime of reading the file, so the whole runtime is O(c * log(N) + r)
, where c is the number of different cows, r is the number of lines and N is the max number of cow weights' length.