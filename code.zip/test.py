import heapq
import math

class CowRecord:
    """the class of all records of a cow, used as the data struct"""
    def __init__(self, cow_id):
        '''init the attributes.

        id: the id of cow
        heap: the data struct of min-heap
        least: the least weight
        milks: the list of milks
        temps: the list of milks
        '''
        self.id = cow_id
        self.heap = []
        self.least = None
        self.milks = []
        self.temps = []
    
    def addWright(self, weight):
        """add the weight into the min-heap and reset the least weight"""
        heapq.heappush(self.heap, weight)
        self.least = weight
    
    def addMilk(self, milk):
        """add the milk into the milks"""
        self.milks.append(int(milk))
    
    def addTemp(self, temp):
        """add the temperature into the temps"""
        self.temps.append(temp)
    

def readFile(path):
    """read data from the given path"""
    lines = []
    with open(path, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    return lines[0], lines[1:]

if __name__ == "__main__":
    # the path of the file, you should replace the path into yours
    path = r'C:\Users\AnShuShan\Desktop\DAFresults\test.txt'
    res_dict = {}
    nums, cow_lines = readFile(path)
    # process data and create the data structs
    for cow in cow_lines:
        cow_id, feature, number, time = cow.split(' ')
        c = res_dict.get(cow_id, CowRecord(cow_id))
        if feature == 'W':
            c.addWright(number)
        elif feature == 'M':
            c.addMilk(number)
        else:
            c.addTemp(number)
        res_dict[cow_id] = c
    # print the results
    for cow_id, cow in res_dict.items():
        if len(cow.milks) == 0 or len(cow.heap) == 0:
            continue
        print(cow_id, cow.heap[0], cow.least, sum(cow.milks) // len(cow.milks))